#!/usr/bin/env python3
"""Run an exported transport or resume an exported machine state.

Examples:
  python run_artifact.py examples/generated_transport.json 10
  python run_artifact.py examples/replaceable_evaluator.json --use-stored-input
  python run_artifact.py examples/suspended_computation.json --resume

Use only this prototype's artifacts or other trusted test inputs. This runtime
has semantic budgets but has not been security-hardened against hostile files.
"""
import argparse
import json
from pathlib import Path
from workspace import Graph,Workspace,Machine,WorkspaceError


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('artifact',type=Path)
    parser.add_argument('integer',nargs='?',type=int)
    parser.add_argument('--use-stored-input',action='store_true')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--fuel',type=int,default=100000)
    args=parser.parse_args()
    if not args.artifact.is_file():parser.error('artifact file does not exist')
    try:
        g=Graph();roots=g.load(args.artifact.read_bytes())
        if not roots:raise WorkspaceError('artifact has no root')
        if args.resume:
            result=Machine(g).run(checkpoint=roots[0],fuel=args.fuel)
            value=result.value
        else:
            if args.use_stored_input:
                if len(roots)<2:raise WorkspaceError('artifact has no stored input')
                input_ref=roots[1]
            else:
                if args.integer is None:parser.error('provide an integer or --use-stored-input')
                input_ref=g.integer(args.integer)
            result=Workspace(g).run(roots[0],input_ref,fuel=args.fuel)
            value=result.output
        record={'status':result.status,'steps':result.steps,'error':result.error}
        if value is not None:
            node=g.get(value)
            record['output']=g.number(value) if node.tag=='integer' else {'tag':node.tag,'links':len(node.links)}
        print(json.dumps(record,indent=2))
        return 0 if result.status=='ok' else 1
    except (OSError,WorkspaceError) as exc:
        parser.exit(1,f'Error: {exc}\n')

if __name__=='__main__':raise SystemExit(main())
