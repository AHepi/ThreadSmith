"""Two general lambda interpreters expressed entirely in the workspace language.

They consume a *different* expression grammar (m/literal, m/variable, m/function,
m/application). The evaluator source is ordinary graph material. No call to the
native `eval` primitive interprets the subject language. m/wrap is a convenience
for observing Church numerals as nested successor nodes, not a recursion opcode.
"""
from workspace import V,F,C,L,O,I,LET,compile_expr,Workspace,Graph
from experiments import MAKE,good


def evaluator_source(lazy: bool):
    # A recursively defined lookup operation over an explicitly represented
    # linked environment. Its binding values are values (strict) or thunks (lazy).
    seek_body = I(O('int.eq', V('index'), L(0)),
                  O('link', V('environment'), L(0)),
                  C(C(V('seek'), V('seek')),
                    O('list',O('int.sub',V('index'),L(1)),
                             O('link',V('environment'),L(1)))))
    lookup = F('seek', F('request',
                LET('index',O('link',V('request'),L(0)),
                  LET('environment',O('link',V('request'),L(1)),seek_body))))

    def evaluate(expression,environment):
        return C(C(V('self'),V('self')),O('list',expression,environment))
    expression,environment = V('expression'),V('environment')
    child = lambda i: O('link',expression,L(i))
    found = C(C(V('lookup'),V('lookup')),O('list',child(0),environment))
    variable = (LET('thunk',found,
                    evaluate(O('link',V('thunk'),L(0)),O('link',V('thunk'),L(1))))
                if lazy else found)
    function = MAKE('m/closure',L(b''),child(0),environment)
    argument = (MAKE('m/thunk',L(b''),child(1),environment)
                if lazy else evaluate(child(1),environment))
    applied_environment = MAKE('m/environment',L(b''),V('argument'),O('link',V('function'),L(1)))
    apply_body = LET('argument',argument,
                     evaluate(O('link',V('function'),L(0)),applied_environment))
    application = LET('function',evaluate(child(0),environment),
                       I(O('value.eq',O('tag',V('function')),L('m/closure')),
                         apply_body,O('fail',L('meta-evaluator: non-function application'))))
    cases = [('m/literal',child(0)),('m/variable',variable),('m/function',function),
             ('m/application',application),
             ('m/wrap',MAKE('m/successor',L(b''),evaluate(child(0),environment)))]
    dispatch=O('fail',L('meta-evaluator: unknown expression'))
    for tag,result in reversed(cases):
        dispatch=I(O('value.eq',O('tag',expression),L(tag)),result,dispatch)
    evaluator=F('self',F('request',
                LET('expression',O('link',V('request'),L(0)),
                    LET('environment',O('link',V('request'),L(1)),dispatch))))
    entry=F('source',C(C(V('evaluator'),V('evaluator')),
                      O('list',V('source'),MAKE('m/empty',L(b'')))))
    return LET('lookup',lookup,LET('evaluator',evaluator,entry))


class Subject:
    """Authoring helpers for the independently interpreted lambda grammar."""
    def __init__(self,g):self.g=g
    def var(self,i):return self.g.add('m/variable',links=(self.g.integer(i),))
    def literal(self,x):return self.g.add('m/literal',links=(self.g.integer(x),))
    def fn(self,body):return self.g.add('m/function',links=(body,))
    def call(self,f,a):return self.g.add('m/application',links=(f,a))
    def wrap(self,x):return self.g.add('m/wrap',links=(x,))
    def church(self,n):
        x=self.var(0);f=self.var(1)
        for _ in range(n):x=self.call(f,x)
        return self.fn(self.fn(x))
    def plus(self):
        # λm.λn.λf.λx. m f (n f x); de Bruijn positions 3,2,1,0.
        m,n,f,x=[self.var(i) for i in (3,2,1,0)]
        result=self.call(self.call(m,f),self.call(self.call(n,f),x))
        for _ in range(4):result=self.fn(result)
        return result


def experiment(export=None):
    w=Workspace();g=w.g;s=Subject(g)
    interpreters={name:w.transport(name,compile_expr(g,evaluator_source(lazy)))
                  for name,lazy in [('strict',False),('lazy',True)]}
    # The same expression terminates only under the non-strict interpretation.
    self_application=s.fn(s.call(s.var(0),s.var(0)))
    omega=s.call(self_application,self_application)
    challenge=s.call(s.fn(s.literal(42)),omega)
    strict=w.run(interpreters['strict'],challenge,fuel=5000)
    lazy=w.run(interpreters['lazy'],challenge,fuel=5000)
    assert strict.status=='error' and 'suspended' in strict.error
    assert g.number(good(lazy))==42
    hole = g.add('still-uninterpreted-hole', b'no meaning supplied')
    partial = s.call(s.fn(s.literal(42)), hole)
    strict_partial = w.run(interpreters['strict'], partial, fuel=5000)
    lazy_partial = w.run(interpreters['lazy'], partial, fuel=5000)
    assert strict_partial.status == 'error'
    assert g.number(good(lazy_partial)) == 42
    # Universal lambda behaviour beyond the termination counterexample.
    church_sum=s.call(s.call(s.plus(),s.church(3)),s.church(2))
    observable=s.call(s.call(church_sum,s.fn(s.wrap(s.var(0)))),s.literal(0))
    observed={};steps={}
    for name,interpreter in interpreters.items():
        result=w.run(interpreter,observable,fuel=200000)
        value=good(result);n=0
        while g.get(value).tag=='m/successor':
            n+=1;value=g.get(value).links[0]
        assert g.number(value)==0 and n==5
        observed[name]=n;steps[name]=result.steps
    # Copy the interpreter itself, not a pre-computed answer, into a fresh runtime.
    wire=g.dump([interpreters['lazy'],challenge])
    clone=Graph();t,expr=clone.load(wire);fresh=Workspace(clone)
    after=clone.number(good(fresh.run(t,expr,fuel=10000)))
    assert after==42
    if export:
        (export/'replaceable_evaluator.json').write_bytes(wire)
    return {'interpreters_written_in_workspace_language':2,
            'subject_language':'untyped lambda expressions with a separate node grammar',
            'strict_on_ignored_divergent_argument':strict.error,
            'strict_step_budget':5000,'lazy_on_same_expression':42,
            'unused_uninterpreted_hole_strict_status':strict_partial.status,
            'unused_uninterpreted_hole_lazy_result':42,
            'church_3_plus_2_under_both_interpreters':observed,
            'church_test_steps':steps,
            'interpreter_export_import_result':after,
            'evaluator_export_nodes':len(__import__('json').loads(wire)['nodes']),
            'no_native_eval_for_subject_program':True,
            'authorship':'Both general evaluator programs authored by the experimenter; not autonomously invented.'}
