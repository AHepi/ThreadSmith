"""Open-expression workspace prototype, Python 3.10+, standard library only.

All persistent material -- data, code, closures, ports, pipeline connections,
execution records, revisions and suspended computations -- is an explicit graph.
The evaluator is an iterative call-by-value lambda machine; no Python eval/exec.
This is a research prototype, NOT a hardened multi-tenant execution sandbox.
"""
from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable


class WorkspaceError(Exception):
    pass


class Limit(WorkspaceError):
    pass


@dataclass(frozen=True)
class Local:
    """Reference to a node in a batch that has not yet been committed."""
    index: int


@dataclass(frozen=True)
class Node:
    tag: str
    payload: bytes = b""
    links: tuple[int, ...] = ()


class Graph:
    def __init__(self, *, max_nodes: int = 1_000_000,
                 max_payload: int = 1_048_576, max_links: int = 100_000):
        self.nodes: list[Node] = []
        self.max_nodes = max_nodes
        self.max_payload = max_payload
        self.max_links = max_links

    def __len__(self) -> int:
        return len(self.nodes)

    def get(self, ref: int) -> Node:
        if type(ref) is not int or not 0 <= ref < len(self.nodes):
            raise WorkspaceError(f"Invalid reference: {ref!r}")
        return self.nodes[ref]

    def _validate_shape(self, tag: str, payload: bytes, links: tuple) -> None:
        if not isinstance(tag, str) or not isinstance(payload, bytes):
            raise WorkspaceError("Tags must be strings, payloads must be bytes")
        if len(tag.encode('utf-8')) > self.max_payload:
            raise Limit("tag size limit")
        if len(payload) > self.max_payload or len(links) > self.max_links:
            raise Limit("node size limit")

    def add(self, tag: str, payload: bytes = b"", links: Iterable[int] = ()) -> int:
        links = tuple(links)
        self._validate_shape(tag, payload, links)
        if len(self.nodes) >= self.max_nodes:
            raise Limit("graph allocation limit")
        for ref in links:
            self.get(ref)
        ref = len(self.nodes)
        self.nodes.append(Node(tag, payload, links))
        return ref

    def batch(self, specifications: list[tuple[str, bytes, tuple[int | Local, ...]]]) -> list[int]:
        """Atomically allocate a finite graph, including sharing and cycles."""
        start, size = len(self.nodes), len(specifications)
        if start + size > self.max_nodes:
            raise Limit("graph allocation limit")
        pending = []
        for tag, payload, links in specifications:
            self._validate_shape(tag, payload, links)
            resolved = []
            for ref in links:
                if isinstance(ref, Local):
                    if type(ref.index) is not int or not 0 <= ref.index < size:
                        raise WorkspaceError("invalid local reference")
                    resolved.append(start + ref.index)
                else:
                    self.get(ref)
                    resolved.append(ref)
            pending.append(Node(tag, payload, tuple(resolved)))
        self.nodes.extend(pending)
        return list(range(start, start + size))

    def integer(self, value: int) -> int:
        if type(value) is not int:
            raise WorkspaceError("integer required; booleans are distinct")
        return self.add('integer', str(value).encode('ascii'))

    def number(self, ref: int) -> int:
        node = self.get(ref)
        if node.tag != 'integer' or node.links:
            raise WorkspaceError(f"integer required, got {node.tag}")
        try:
            return int(node.payload)
        except ValueError as exc:
            raise WorkspaceError("invalid integer payload") from exc

    def text(self, value: str) -> int:
        return self.add('text', value.encode('utf-8'))

    def string(self, ref: int) -> str:
        node = self.get(ref)
        if node.tag != 'text' or node.links:
            raise WorkspaceError("text required")
        try:
            return node.payload.decode('utf-8')
        except UnicodeDecodeError as exc:
            raise WorkspaceError("invalid UTF-8") from exc

    def binary(self, value: bytes) -> int:
        return self.add('bytes', value)

    def sequence(self, refs: Iterable[int] = ()) -> int:
        return self.add('list', links=refs)

    def items(self, ref: int) -> tuple[int, ...]:
        node = self.get(ref)
        if node.tag != 'list':
            raise WorkspaceError("list required")
        return node.links

    def boolean(self, value: bool) -> int:
        return self.add('boolean', b'1' if value else b'0')

    def truth(self, ref: int) -> bool:
        node = self.get(ref)
        if node.tag != 'boolean' or node.payload not in (b'0', b'1') or node.links:
            raise WorkspaceError("boolean required")
        return node.payload == b'1'

    def dump(self, roots: Iterable[int]) -> bytes:
        """Lossless reachable-graph encoding; preserves aliasing and cycles."""
        roots = list(roots)
        order: list[int] = []
        index: dict[int, int] = {}
        def register(ref: int) -> None:
            self.get(ref)
            if ref not in index:
                index[ref] = len(order)
                order.append(ref)
        for ref in roots:
            register(ref)
        cursor = 0
        while cursor < len(order):
            for ref in self.get(order[cursor]).links:
                register(ref)
            cursor += 1
        records = [[self.get(ref).tag,
                    base64.b64encode(self.get(ref).payload).decode('ascii'),
                    [index[x] for x in self.get(ref).links]] for ref in order]
        return json.dumps({'format': 'open-graph/1', 'roots': [index[x] for x in roots],
                           'nodes': records}, ensure_ascii=True,
                          separators=(',', ':')).encode('utf-8')

    def load(self, data: bytes) -> list[int]:
        """Import data, NOT execute it. Check every reference before allocation."""
        if len(data) > 64 * 1024 * 1024:
            raise Limit("import size limit")
        try:
            document = json.loads(data)
            if document['format'] != 'open-graph/1':
                raise WorkspaceError("unknown wire format")
            records = document['nodes']
            roots = document['roots']
            if not isinstance(records, list) or not isinstance(roots, list):
                raise WorkspaceError("nodes and roots must be lists")
            if len(records) > self.max_nodes - len(self):
                raise Limit("import allocation limit")
            for root in roots:
                if type(root) is not int or not 0 <= root < len(records):
                    raise WorkspaceError("bad imported root")
            specs = []
            for record in records:
                if not isinstance(record, list) or len(record) != 3:
                    raise WorkspaceError("bad imported node")
                tag, payload, links = record
                if not isinstance(links, list):
                    raise WorkspaceError("bad imported links")
                specs.append((tag, base64.b64decode(payload, validate=True),
                              tuple(Local(x) for x in links)))
            ids = self.batch(specs)
            return [ids[x] for x in roots]
        except (KeyError, TypeError, ValueError) as exc:
            raise WorkspaceError(f"Invalid wire graph: {exc}") from exc

    def digest(self, roots: Iterable[int]) -> str:
        return hashlib.sha256(self.dump(roots)).hexdigest()


# Small authoring DSL. It compiles to ordinary workspace nodes, not host closures.
def V(name: str): return ('var', name)
def F(name: str, body): return ('fn', name, body)
def C(fn, arg): return ('call', fn, arg)
def Q(ref: int): return ('quote', ref)
def L(value): return ('literal', value)
def O(name: str, *args): return ('op', name, *args)
def I(test, yes, no): return ('if', test, yes, no)
def E(code): return ('eval', code)
def LET(name, value, body): return C(F(name, body), value)


def compile_expr(g: Graph, expression, scope: tuple[str, ...] = ()) -> int:
    kind = expression[0]
    if kind == 'var':
        try:
            index = scope.index(expression[1])
        except ValueError as exc:
            raise WorkspaceError(f"Unbound name {expression[1]}") from exc
        return g.add('v', str(index).encode())
    if kind == 'fn':
        return g.add('fn', links=(compile_expr(g, expression[2], (expression[1],) + scope),))
    if kind == 'quote':
        return g.add('q', links=(expression[1],))
    if kind == 'literal':
        value = expression[1]
        if type(value) is bool: ref = g.boolean(value)
        elif type(value) is int: ref = g.integer(value)
        elif isinstance(value, str): ref = g.text(value)
        elif isinstance(value, bytes): ref = g.binary(value)
        else: raise WorkspaceError(f"Unsupported authoring literal {type(value)}")
        return g.add('q', links=(ref,))
    if kind in ('call', 'if', 'eval'):
        return g.add(kind, links=(compile_expr(g, x, scope) for x in expression[1:]))
    if kind == 'op':
        return g.add('op', expression[1].encode(),
                     (compile_expr(g, x, scope) for x in expression[2:]))
    raise WorkspaceError(f"Unknown authoring form {kind}")


@dataclass
class Evaluation:
    status: str
    value: int | None
    steps: int
    checkpoint: int | None = None
    error: str | None = None


class Machine:
    """An iterative CEK-style machine; captured environments are graph nodes.

    Frame tuples are reified into the graph when a run is suspended. Step limits
    are cooperative semantic limits, not a production CPU/memory security proof.
    """
    def __init__(self, graph: Graph, *, max_integer_bits: int = 16_384):
        self.g = graph
        self.empty_env = graph.add('environment')
        self.max_integer_bits = max_integer_bits

    def _arity(self, values: tuple, count: int):
        if len(values) != count:
            raise WorkspaceError(f"arity: expected {count}, got {len(values)}")

    def primitive(self, name: str, args: tuple[int, ...]) -> int:
        g = self.g
        if name.startswith('int.'):
            self._arity(args, 2)
            a, b = map(g.number, args)
            if name == 'int.eq': return g.boolean(a == b)
            if name == 'int.lt': return g.boolean(a < b)
            if name == 'int.add': result = a + b
            elif name == 'int.sub': result = a - b
            elif name == 'int.mul':
                if a.bit_length() + b.bit_length() > self.max_integer_bits + 1:
                    raise Limit("integer size limit")
                result = a * b
            else: raise WorkspaceError(f"Unknown primitive: {name}")
            if result.bit_length() > self.max_integer_bits:
                raise Limit("integer size limit")
            return g.integer(result)
        if name == 'list': return g.sequence(args)
        if name == 'tag':
            self._arity(args, 1); return g.text(g.get(args[0]).tag)
        if name == 'payload':
            self._arity(args, 1); return g.binary(g.get(args[0]).payload)
        if name == 'links':
            self._arity(args, 1); return g.sequence(g.get(args[0]).links)
        if name == 'link':
            self._arity(args, 2)
            edges, i = g.get(args[0]).links, g.number(args[1])
            if not 0 <= i < len(edges): raise WorkspaceError("link index out of range")
            return edges[i]
        if name == 'make':
            self._arity(args, 3)
            p = g.get(args[1])
            if p.tag != 'bytes' or p.links: raise WorkspaceError("byte payload required")
            return g.add(g.string(args[0]), p.payload, g.items(args[2]))
        if name == 'batch':
            self._arity(args, 1)
            specifications = []
            for spec_ref in g.items(args[0]):
                spec = g.get(spec_ref)
                if spec.tag != 'node-spec' or len(spec.links) != 3:
                    raise WorkspaceError('invalid batch specification')
                tag, payload_ref, references = spec.links
                payload = g.get(payload_ref)
                if payload.tag != 'bytes': raise WorkspaceError('batch payload must be bytes')
                links = []
                for reference in g.items(references):
                    r = g.get(reference)
                    if r.tag == 'local' and not r.links:
                        try: links.append(Local(int(r.payload)))
                        except ValueError as exc: raise WorkspaceError('invalid local index') from exc
                    elif r.tag == 'existing' and len(r.links) == 1:
                        links.append(r.links[0])
                    else: raise WorkspaceError('batch reference must be local or existing')
                specifications.append((g.string(tag), payload.payload, tuple(links)))
            return g.sequence(g.batch(specifications))
        if name == 'value.eq':
            self._arity(args, 2)
            a, b = map(g.get, args)
            if a.links or b.links: raise WorkspaceError("value.eq is for atoms only")
            return g.boolean(a.tag == b.tag and a.payload == b.payload)
        if name == 'same.ref':
            self._arity(args, 2); return g.boolean(args[0] == args[1])
        if name == 'bytes.pack':
            self._arity(args, 1)
            values = [g.number(x) for x in g.items(args[0])]
            if any(not 0 <= x <= 255 for x in values): raise WorkspaceError('byte out of range')
            return g.binary(bytes(values))
        if name == 'bytes.concat':
            self._arity(args, 2)
            nodes = [g.get(x) for x in args]
            if any(x.tag != 'bytes' or x.links for x in nodes): raise WorkspaceError('bytes required')
            if sum(len(x.payload) for x in nodes) > g.max_payload: raise Limit('byte size limit')
            return g.binary(nodes[0].payload + nodes[1].payload)
        if name == 'bytes.get':
            self._arity(args, 2)
            node, i = g.get(args[0]), g.number(args[1])
            if node.tag != 'bytes' or not 0 <= i < len(node.payload):
                raise WorkspaceError("byte index/type error")
            return g.integer(node.payload[i])
        if name == 'bytes.len':
            self._arity(args, 1)
            if g.get(args[0]).tag != 'bytes': raise WorkspaceError("bytes required")
            return g.integer(len(g.get(args[0]).payload))
        if name == 'bytes.utf8':
            self._arity(args, 1)
            if g.get(args[0]).tag != 'bytes': raise WorkspaceError("bytes required")
            try: return g.text(g.get(args[0]).payload.decode('utf-8'))
            except UnicodeDecodeError as exc: raise WorkspaceError("not UTF-8; raw bytes preserved") from exc
        if name == 'text.bytes':
            self._arity(args, 1); return g.binary(g.string(args[0]).encode('utf-8'))
        if name == 'fail':
            self._arity(args, 1); raise WorkspaceError(g.string(args[0]))
        raise WorkspaceError(f"Unknown primitive: {name}")

    def run(self, expression: int | None = None, *, fuel: int = 100_000,
            checkpoint: int | None = None, allocation_budget: int = 100_000) -> Evaluation:
        g = self.g
        if fuel < 0: raise ValueError("fuel must be nonnegative")
        if checkpoint is None:
            if expression is None: raise ValueError("expression required")
            control, env, mode, frames = expression, self.empty_env, 'eval', []
        else:
            state = g.get(checkpoint)
            if state.tag != 'machine-state' or len(state.links) < 2:
                raise WorkspaceError("invalid checkpoint")
            mode = state.payload.decode()
            if mode not in ('eval', 'return'): raise WorkspaceError("invalid checkpoint mode")
            control, env = state.links[:2]
            frames = [(g.get(x).tag.removeprefix('frame/'), g.get(x).payload,
                       g.get(x).links) for x in state.links[2:]]
        steps = 0
        initial_nodes = len(g)
        try:
            while True:
                if len(g) - initial_nodes >= allocation_budget:
                    raise Limit('per-evaluation allocation budget')
                if mode == 'return' and not frames:
                    return Evaluation('ok', control, steps)
                if steps >= fuel:
                    saved_frames = [g.add('frame/' + tag, payload, links)
                                    for tag, payload, links in frames]
                    saved = g.add('machine-state', mode.encode(), (control, env, *saved_frames))
                    return Evaluation('suspended', None, steps, checkpoint=saved)
                steps += 1
                if mode == 'eval':
                    node = g.get(control)
                    if node.tag == 'q':
                        self._arity(node.links, 1)
                        control, mode = node.links[0], 'return'
                    elif node.tag == 'v':
                        self._arity(node.links, 0)
                        try: index = int(node.payload)
                        except ValueError as exc: raise WorkspaceError("bad variable index") from exc
                        environment = g.get(env)
                        if environment.tag != 'environment' or not 0 <= index < len(environment.links):
                            raise WorkspaceError("unbound variable")
                        control, mode = environment.links[index], 'return'
                    elif node.tag == 'fn':
                        self._arity(node.links, 1)
                        control = g.add('closure', links=(node.links[0], env))
                        mode = 'return'
                    elif node.tag == 'call':
                        self._arity(node.links, 2)
                        frames.append(('function', b'', (node.links[1], env)))
                        control = node.links[0]
                    elif node.tag == 'if':
                        self._arity(node.links, 3)
                        frames.append(('branch', b'', (node.links[1], node.links[2], env)))
                        control = node.links[0]
                    elif node.tag == 'op':
                        if not node.links:
                            control = self.primitive(node.payload.decode(), ())
                            mode = 'return'
                        else:
                            frames.append(('primitive', b'', (control, env)))
                            control = node.links[0]
                    elif node.tag == 'eval':
                        self._arity(node.links, 1)
                        frames.append(('evaluate', b'', ()))
                        control = node.links[0]
                    else:
                        raise WorkspaceError(f"Unknown syntax: {node.tag}")
                else:
                    tag, payload, refs = frames.pop()
                    if tag == 'function':
                        frames.append(('argument', b'', (control,)))
                        control, env, mode = refs[0], refs[1], 'eval'
                    elif tag == 'argument':
                        closure = g.get(refs[0])
                        if closure.tag != 'closure' or len(closure.links) != 2:
                            raise WorkspaceError("attempt to call non-function")
                        old_env = g.get(closure.links[1])
                        if old_env.tag != 'environment': raise WorkspaceError("bad closure environment")
                        env = g.add('environment', links=(control, *old_env.links))
                        control, mode = closure.links[0], 'eval'
                    elif tag == 'branch':
                        control = refs[0] if g.truth(control) else refs[1]
                        env, mode = refs[2], 'eval'
                    elif tag == 'primitive':
                        source, saved_env, *completed = refs
                        completed.append(control)
                        operation = g.get(source)
                        if len(completed) < len(operation.links):
                            frames.append(('primitive', b'', (source, saved_env, *completed)))
                            control, env, mode = operation.links[len(completed)], saved_env, 'eval'
                        else:
                            control = self.primitive(operation.payload.decode(), tuple(completed))
                    elif tag == 'evaluate':
                        env, mode = self.empty_env, 'eval'
                    else:
                        raise WorkspaceError(f"Invalid continuation frame {tag}")
        except (WorkspaceError, UnicodeError) as exc:
            return Evaluation('limit' if isinstance(exc, Limit) else 'error', None, steps,
                              error=str(exc))


@dataclass
class Run:
    status: str
    output: int | None
    event: int
    steps: int
    error: str | None = None


class Workspace:
    """A graph plus explicit execution and revision controls.

    Transport descriptor: (input-tag, reader, operator, writer, output-tag).
    Reader/operator/writer are graph expressions evaluating to functions.
    A descriptor has no effect merely by being stored or imported.
    """
    def __init__(self, graph: Graph | None = None):
        self.g = graph if graph is not None else Graph()
        self.vm = Machine(self.g)
        self.identity = compile_expr(self.g, F('x', V('x')))
        self.head = self.g.add('revision', b'initial')

    def transport(self, name: str, operator: int, *, reader: int | None = None,
                  writer: int | None = None, input_tag: str = '*', output_tag: str = '*') -> int:
        return self.g.add('transport', name.encode('utf-8'),
                          (self.g.text(input_tag), self.identity if reader is None else reader,
                           operator, self.identity if writer is None else writer,
                           self.g.text(output_tag)))

    def pipeline(self, name: str, transports: Iterable[int]) -> int:
        return self.g.add('pipeline', name.encode('utf-8'), transports)

    def _stages(self, descriptor: int) -> list[int]:
        # Expand only explicit finite pipelines; cycles are not guessed to be delays.
        todo = [('visit', descriptor)]
        active = set()
        stages = []
        while todo:
            action, ref = todo.pop()
            if action == 'leave':
                active.remove(ref); continue
            node = self.g.get(ref)
            if node.tag == 'transport':
                stages.append(ref)
                if len(stages) > 10_000: raise Limit("pipeline stage limit")
            elif node.tag == 'pipeline':
                if ref in active: raise WorkspaceError("pipeline cycle requires an explicit state/delay interpretation")
                active.add(ref)
                todo.append(('leave', ref))
                todo.extend(('visit', x) for x in reversed(node.links))
            else:
                raise WorkspaceError(f"Not a transport: {node.tag}")
        return stages

    def run(self, descriptor: int, input_ref: int, *, fuel: int = 100_000) -> Run:
        g = self.g
        source = input_ref
        total_steps = 0
        events = []
        try:
            for transport in self._stages(descriptor):
                node = g.get(transport)
                if len(node.links) != 5: raise WorkspaceError("invalid transport descriptor")
                in_shape, reader, operation, writer, out_shape = node.links
                expected = g.string(in_shape)
                if expected != '*' and g.get(input_ref).tag != expected:
                    raise WorkspaceError(f"input contract: expected {expected}, got {g.get(input_ref).tag}")
                transport_input = input_ref
                phase_events = []
                for role, program in (('reader', reader), ('operator', operation), ('writer', writer)):
                    call = g.add('call', links=(program, g.add('q', links=(input_ref,))))
                    result = self.vm.run(call, fuel=max(0, fuel - total_steps))
                    total_steps += result.steps
                    outputs = () if result.value is None else (result.value,)
                    continuation = () if result.checkpoint is None else (result.checkpoint,)
                    event = g.add('phase-run', json.dumps({'role': role, 'status': result.status,
                                  'steps': result.steps, 'error': result.error}).encode(),
                                  (program, input_ref, *outputs, *continuation))
                    phase_events.append(event)
                    if result.status != 'ok':
                        events.extend(phase_events)
                        raise WorkspaceError(f"{role}: {result.status}: {result.error or 'step budget exhausted'}")
                    input_ref = result.value
                expected = g.string(out_shape)
                if expected != '*' and g.get(input_ref).tag != expected:
                    raise WorkspaceError(f"output contract: expected {expected}, got {g.get(input_ref).tag}")
                events.append(g.add('transport-run', links=(transport, transport_input, input_ref, *phase_events)))
            event = g.add('run', json.dumps({'status': 'ok', 'steps': total_steps}).encode(),
                          (descriptor, source, input_ref, *events))
            return Run('ok', input_ref, event, total_steps)
        except WorkspaceError as exc:
            event = g.add('run', json.dumps({'status': 'error', 'steps': total_steps,
                                           'error': str(exc)}).encode(), (descriptor, source, *events))
            return Run('error', None, event, total_steps, str(exc))

    def revision(self, parent: int, updates: dict[str, int], name: str = '') -> int:
        """Construct a candidate revision. Does not silently select it."""
        if self.g.get(parent).tag != 'revision': raise WorkspaceError("revision parent required")
        entries = [self.g.add('binding', key.encode(), (value,)) for key, value in sorted(updates.items())]
        return self.g.add('revision', name.encode(), (parent, *entries))

    def select(self, revision: int, *, expected_head: int) -> None:
        if self.head != expected_head: raise WorkspaceError("stale selection; branch preserved")
        if self.g.get(revision).tag != 'revision': raise WorkspaceError("revision required")
        self.head = revision

    def lookup(self, name: str, revision: int | None = None) -> int:
        current = self.head if revision is None else revision
        seen = set()
        while True:
            if current in seen: raise WorkspaceError('cyclic revision chain')
            seen.add(current)
            node = self.g.get(current)
            if node.tag != 'revision': raise WorkspaceError("invalid revision chain")
            if not node.links: raise WorkspaceError(f"unknown binding {name}")
            for entry_ref in node.links[1:]:
                entry = self.g.get(entry_ref)
                if entry.tag == 'binding' and entry.payload.decode() == name:
                    return entry.links[0]
            current = node.links[0]
