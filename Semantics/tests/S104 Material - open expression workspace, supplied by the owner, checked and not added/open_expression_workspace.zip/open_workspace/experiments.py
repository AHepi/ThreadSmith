#!/usr/bin/env python3
"""Run the workspace experiments and save machine-readable evidence.

Run: python experiments.py --out results.json --export-dir examples
No dependencies, network calls or LLM calls. Supplied test fixtures and selection
criteria are explicitly designer-authored. Generated transport graphs are not.
"""
from __future__ import annotations

import argparse
import itertools
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

from workspace import Graph, Local, Machine, Workspace, WorkspaceError
from workspace import V, F, C, Q, L, O, I, E, LET, compile_expr


def good(result):
    assert result.status == 'ok', result
    return result.value if hasattr(result, 'value') else result.output


def MAKE(tag, payload, *links):
    """An in-language graph constructor expression, not a host-side constructor."""
    return O('make', L(tag), payload, O('list', *links))


def storage_experiment(export: Path | None) -> dict:
    g = Graph()
    binary = g.binary(bytes(range(256)) + b'\xff\x00\xfe')
    text = g.text('Boundary? relation? 未命名 — 🌀')
    a, b = g.text('same-name'), g.text('same-name')
    cycle = g.batch([
        ('unregistered/first', b'opaque\x00payload', (Local(1), a, a)),
        ('unregistered/second', b'\xff', (Local(0), b)),
    ])
    hole = g.add('unfinished-expression', b'no interpretation installed')
    roots = [binary, text, *cycle, a, b, hole]
    wire = g.dump(roots)
    restored = Graph()
    imported = restored.load(wire)
    assert restored.dump(imported) == wire
    first = restored.get(imported[2])
    second = restored.get(imported[3])
    assert first.links[0] == imported[3] and second.links[0] == imported[2]
    assert first.links[1] == first.links[2]
    assert imported[4] != imported[5]
    assert restored.get(imported[0]).payload == bytes(range(256)) + b'\xff\x00\xfe'
    random_generator = random.Random(707)
    for _ in range(200):
        h = Graph()
        n = random_generator.randrange(1, 40)
        specs = []
        for j in range(n):
            specs.append((f'new-kind/{random_generator.randrange(20)}',
                          random_generator.randbytes(random_generator.randrange(20)),
                          tuple(Local(random_generator.randrange(n))
                                for _ in range(random_generator.randrange(6)))))
        refs = h.batch(specs)
        dump = h.dump(refs)
        clone = Graph()
        assert clone.dump(clone.load(dump)) == dump
    dag = Graph()
    root = dag.text('leaf')
    for _ in range(20): root = dag.add('fork', links=(root, root))
    if export: (export / 'heterogeneous_graph.json').write_bytes(wire)
    return {'mixed_graph_roundtrip': True, 'random_graph_roundtrips': 200,
            'cycles_preserved': True, 'sharing_preserved': True,
            'equal_labels_did_not_merge_identity': True,
            'arbitrary_bytes_preserved': 259,
            'uninterpreted_and_unfinished_forms_preserved': True,
            'shared_dag_nodes': len(dag), 'naive_unfolded_tree_nodes': 2**21 - 1}


def computing_experiment(export: Path | None) -> dict:
    w = Workspace(); g = w.g
    factorial = F('self', F('n',
        I(O('int.eq', V('n'), L(0)), L(1),
          O('int.mul', V('n'), C(C(V('self'), V('self')), O('int.sub', V('n'), L(1)))))))
    f = compile_expr(g, factorial)
    factorial_results = {}
    for n in (0, 1, 5, 10, 20):
        expr = compile_expr(g, C(C(E(Q(f)), E(Q(f))), L(n)))
        result = w.vm.run(expr)
        factorial_results[str(n)] = g.number(good(result))
    assert factorial_results['20'] == 2432902008176640000

    # Church numerals and addition exercise the lambda fragment, not host arithmetic.
    def church(n):
        result = V('x')
        for _ in range(n): result = C(V('f'), result)
        return F('f', F('x', result))
    add = F('m', F('n', F('f', F('x', C(C(V('m'), V('f')), C(C(V('n'), V('f')), V('x')))))))
    expr = C(C(C(C(add, church(3)), church(2)), F('x', O('int.add', V('x'), L(1)))), L(0))
    church_result = g.number(good(w.vm.run(compile_expr(g, expr))))
    assert church_result == 5

    closure = good(w.vm.run(compile_expr(g, C(F('k', F('x', O('int.add', V('k'), V('x')))), L(40)))))
    wire = g.dump([closure])
    g2 = Graph(); restored_closure = g2.load(wire)[0]; machine = Machine(g2)
    closure_result = g2.number(good(machine.run(compile_expr(g2, C(Q(restored_closure), L(2))))))
    assert closure_result == 42

    # Deep non-tail recursion avoids Python recursion; suspend, serialize and resume.
    deep = compile_expr(g, C(C(E(Q(f)), E(Q(f))), L(100)))
    pause = w.vm.run(deep, fuel=37)
    assert pause.status == 'suspended'
    wire = g.dump([pause.checkpoint])
    g3 = Graph(); checkpoint = g3.load(wire)[0]; resumed = Machine(g3).run(checkpoint=checkpoint)
    import math
    assert g3.number(good(resumed)) == math.factorial(100)

    self_app = F('x', C(V('x'), V('x')))
    omega = compile_expr(g, C(self_app, self_app))
    diverging = w.vm.run(omega, fuel=1000)
    assert diverging.status == 'suspended' and diverging.steps == 1000
    limited = w.vm.run(omega, fuel=10000, allocation_budget=25)
    assert limited.status == 'limit'
    if export:
        (export / 'captured_function.json').write_bytes(g.dump([closure]))
        (export / 'suspended_computation.json').write_bytes(wire)
    return {'factorials': factorial_results, 'church_3_plus_2': church_result,
            'captured_function_after_roundtrip': closure_result,
            'suspend_export_import_resume_100_factorial': True,
            'suspension_steps': pause.steps, 'resume_steps': resumed.steps,
            'intentional_divergence_status': diverging.status,
            'intentional_divergence_steps': diverging.steps,
            'allocation_limited_status': limited.status,
            'universality_status': 'Architectural lambda-calculus embedding, not established by these finite tests.'}


def interpreter_expression(operation: str):
    """Interpreter in the workspace language for a separately stored grammar."""
    expr = V('expression')
    is_number = O('value.eq', O('tag', expr), L('late/number'))
    is_join = O('value.eq', O('tag', expr), L('late/join'))
    recurse = C(V('self'), V('self'))
    result = O(operation, C(recurse, O('link', expr, L(0))),
                          C(recurse, O('link', expr, L(1))))
    body = I(is_number, O('link', expr, L(0)),
             I(is_join, result, O('fail', L('no interpretation for this notation'))))
    return F('self', F('expression', body))


def interpretation_experiment(export: Path | None) -> dict:
    w = Workspace(); g = w.g
    left = g.add('late/number', links=(g.integer(7),))
    right = g.add('late/number', links=(g.integer(5),))
    expression = g.add('late/join', links=(left, right))
    before = g.digest([expression])
    rejected = w.vm.run(expression)
    assert rejected.status == 'error' and 'Unknown syntax' in rejected.error
    interpreters = {}
    for label, operation in [('addition', 'int.add'), ('multiplication', 'int.mul')]:
        program = compile_expr(g, interpreter_expression(operation))
        usable = compile_expr(g, F('input', C(C(E(Q(program)), E(Q(program))), V('input'))))
        interpreters[label] = w.transport(label, usable, input_tag='late/join', output_tag='integer')
    outcomes = {label: g.number(good(w.run(t, expression))) for label, t in interpreters.items()}
    assert outcomes == {'addition': 12, 'multiplication': 35}
    assert g.digest([expression]) == before

    # Independent host reference calculation on generated nested syntax trees.
    rng = random.Random(91)
    def tree(depth):
        if depth == 0 or rng.random() < .4:
            number = rng.randrange(1, 5)
            return g.add('late/number', links=(g.integer(number),)), number, number
        a, sa, ma = tree(depth - 1); b, sb, mb = tree(depth - 1)
        return g.add('late/join', links=(a, b)), sa + sb, ma * mb
    tests = 0
    for _ in range(100):
        a, sa, ma = tree(4); b, sb, mb = tree(4)
        root = g.add('late/join', links=(a, b))
        for name, expected in [('addition', sa + sb), ('multiplication', ma * mb)]:
            assert g.number(good(w.run(interpreters[name], root))) == expected
            tests += 1
    malformed = g.add('late/join', links=(left,))
    bad = w.run(interpreters['addition'], malformed)
    assert bad.status == 'error'

    base = w.head
    ra = w.revision(base, {'material': expression, 'interpreter': interpreters['addition']}, 'addition context')
    rb = w.revision(base, {'material': expression, 'interpreter': interpreters['multiplication']}, 'multiplication context')
    w.select(ra, expected_head=base)
    stale = False
    try: w.select(rb, expected_head=base)
    except WorkspaceError: stale = True
    assert stale and w.lookup('interpreter', rb) == interpreters['multiplication']
    if export: (export / 'two_interpretations.json').write_bytes(g.dump([expression, ra, rb]))
    return {'same_expression': 'late/join(late/number(7), late/number(5))',
            'before_interpreter': rejected.error,
            'after_installing_graph_interpreters': outcomes,
            'source_unchanged': True, 'nested_interpreter_comparisons': tests,
            'malformed_expression_rejected': True,
            'alternative_contexts_preserved': True, 'stale_selection_rejected': stale,
            'interpreter_authorship': 'Both interpreter definitions supplied by the experimenter, not learned.'}


def constructor_expression(identity: int):
    """Generate executable transport syntax from (operation-name, constant) data.

    Crucially, this executes graph constructors inside the VM. It is not a host
    callback supplying an already-built function for each candidate.
    """
    variable = MAKE('v', L(b'0'))
    constant = MAKE('q', L(b''), O('link', V('spec'), L(1)))
    operation = MAKE('op', O('text.bytes', O('link', V('spec'), L(0))), variable, constant)
    function = MAKE('fn', L(b''), operation)
    return F('spec', MAKE('transport', L(b'generated'), L('integer'), Q(identity),
                         function, Q(identity), L('integer')))


def construction_experiment(export: Path | None) -> dict:
    w = Workspace(); g = w.g
    constructor = w.transport('construct-transport', compile_expr(g, constructor_expression(w.identity)),
                              input_tag='list', output_tag='transport')
    candidates = []
    for operation in ('int.add', 'int.mul'):
        for constant in range(-2, 4):
            spec = g.sequence([g.text(operation), g.integer(constant)])
            transport = good(w.run(constructor, spec))
            candidates.append((operation, constant, transport))
    # Wiring itself is also constructed by an in-language program.
    wire_program = compile_expr(g, F('parts', O('make', L('pipeline'), L(b'generated-wiring'), V('parts'))))
    wire_constructor = w.transport('construct-connection', wire_program, input_tag='list', output_tag='pipeline')
    training = [(-2, -3), (0, 3), (3, 12)]
    inputs = [(g.integer(x), expected) for x, expected in training]
    def score(t):
        return sum(g.number(good(w.run(t, ref))) == expected for ref, expected in inputs)
    single_best = max(score(t) for _, _, t in candidates)
    winners = []
    for a, b in itertools.product(candidates, repeat=2):
        pipeline = good(w.run(wire_constructor, g.sequence([a[2], b[2]])))
        if score(pipeline) == len(training):
            winners.append((a, b, pipeline))
    assert single_best < len(training) and winners
    selected = winners[0]
    # Once selected, export ONLY the connected construction. No named Python
    # callbacks or constructor registry accompany the exported artifact.
    wire = g.dump([selected[2]])
    clean_graph = Graph(); copied = clean_graph.load(wire)[0]; clean_workspace = Workspace(clean_graph)
    held_out = [x for x in range(-100, 101) if x not in {-2, 0, 3}]
    errors = 0
    for x in held_out:
        y = clean_graph.number(good(clean_workspace.run(copied, clean_graph.integer(x))))
        errors += int(y != 3*x + 3)
    assert errors == 0
    if export: (export / 'generated_transport.json').write_bytes(wire)
    return {'generated_elementary_transports': len(candidates),
            'generated_two_stage_connections': len(candidates)**2,
            'training_examples': training,
            'best_single_stage_correct': single_best, 'training_cases': len(training),
            'perfect_connected_candidates': len(winners),
            'selected': [[selected[0][0], selected[0][1]], [selected[1][0], selected[1][1]]],
            'held_out_integer_inputs': len(held_out), 'held_out_errors': errors,
            'exported_construction_nodes': len(json.loads(wire)['nodes']),
            'exported_construction_bytes': len(wire),
            'ran_after_import_without_candidate_registry': True,
            'search_scope': 'Designer-supplied affine building blocks; exhaustive 12^2 search; no LLM.'}


def perception_experiment(export: Path | None) -> dict:
    w = Workspace(); g = w.g
    values = [O('bytes.get', V('pixels'), L(i)) for i in range(4)]
    def add(items):
        result = L(0)
        for item in items: result = O('int.add', result, item)
        return result
    count = add(values)
    a, b, c, d = values
    # Exact component count on the four-cycle square: V-E+1 if all four are on.
    # This is a supplied 2x2-specific interpretation, not a learned vision model.
    edges = add([O('int.mul', a,b), O('int.mul', a,c), O('int.mul', b,d), O('int.mul', c,d)])
    all_on = O('int.mul', O('int.mul', a,b), O('int.mul', c,d))
    components = O('int.add', O('int.sub', count, edges), all_on)
    sum_transport = w.transport('count-lit-pixels', compile_expr(g, F('pixels', count)),
                                input_tag='bytes', output_tag='integer')
    component_transport = w.transport('count-four-neighbour-components',
                                       compile_expr(g, F('pixels', components)),
                                       input_tag='bytes', output_tag='integer')
    groups = defaultdict(Counter)
    examples = []
    errors = 0
    def reference(bits):
        active = {i for i, x in enumerate(bits) if x}
        n = 0
        while active:
            n += 1; stack = [active.pop()]
            while stack:
                i = stack.pop()
                for j in (i ^ 1, i ^ 2):
                    if j in active: active.remove(j); stack.append(j)
        return n
    for bits in itertools.product((0, 1), repeat=4):
        raw = g.binary(bytes(bits))
        summary = w.run(sum_transport, raw)
        total = g.number(good(summary))
        detailed = w.run(component_transport, raw)
        actual = g.number(good(detailed))
        expected = reference(bits)
        errors += actual != expected
        groups[total][expected] += 1
        # A view links source, selected interpretation and result; it never replaces source.
        view = g.add('view', links=(raw, component_transport, detailed.output, detailed.event))
        examples.append((bits, total, expected, raw, view))
    collapsed_best = sum(max(counts.values()) for counts in groups.values())
    assert errors == 0 and collapsed_best == 14
    adjacent = next(e for e in examples if e[0] == (1,1,0,0))
    diagonal = next(e for e in examples if e[0] == (1,0,0,1))
    rejected_summary = w.run(component_transport, g.integer(2))
    assert rejected_summary.status == 'error'
    # Counterexample to silently generalising the 2x2 binary view to grayscale.
    outside = g.binary(bytes([2,0,0,0]))
    outside_result = g.number(good(w.run(component_transport, outside)))

    # Repair the interface explicitly, not by changing the counting operator.
    # Strict reader: exactly four binary samples. Nonzero reader: explicitly
    # adopt a different foreground convention and normalise before counting.
    binary_guard = V('pixels')
    for sample in reversed(values):
        binary_guard = I(O('int.lt', sample, L(2)), binary_guard,
                         O('fail', L('binary image requires samples 0 or 1')))
    binary_guard = I(O('int.eq', O('bytes.len', V('pixels')), L(4)), binary_guard,
                     O('fail', L('2x2 image requires exactly four samples')))
    binary_reader = compile_expr(g, F('pixels', binary_guard))
    normalised = O('bytes.pack', O('list', *[
        I(O('int.eq', sample, L(0)), L(0), L(1)) for sample in values]))
    nonzero_guard = I(O('int.eq', O('bytes.len', V('pixels')), L(4)), normalised,
                      O('fail', L('2x2 image requires exactly four samples')))
    nonzero_reader = compile_expr(g, F('pixels', nonzero_guard))
    existing_operator = g.get(component_transport).links[2]
    strict = w.transport('strict-binary-components', existing_operator, reader=binary_reader,
                          input_tag='bytes', output_tag='integer')
    reinterpret = w.transport('nonzero-foreground-components', existing_operator, reader=nonzero_reader,
                               input_tag='bytes', output_tag='integer')
    assert w.run(strict, outside).status == 'error'
    nonzero_errors = 0
    for pixels in itertools.product((0,1,2), repeat=4):
        raw = g.binary(bytes(pixels))
        predicted = g.number(good(w.run(reinterpret, raw)))
        nonzero_errors += predicted != reference(tuple(int(x != 0) for x in pixels))
    assert nonzero_errors == 0
    assert g.get(outside).payload == bytes([2,0,0,0])
    if export: (export / 'raw_material_and_views.json').write_bytes(g.dump([e[4] for e in examples]))
    return {'binary_2x2_images': 16, 'full_input_component_errors': errors,
            'best_possible_using_only_pixel_count_correct': collapsed_best,
            'best_possible_using_only_pixel_count_accuracy': collapsed_best / 16,
            'ambiguous_pair': [list(adjacent[:3]), list(diagonal[:3])],
            'compressed_input_rejected': True,
            'grayscale_counterexample_input': [2,0,0,0],
            'grayscale_counterexample_output': outside_result,
            'grayscale_nonzero_component_target': 1,
            'structural_port_contract_missed_semantic_violation': outside_result != 1,
            'strict_reader_rejects_grayscale': True,
            'nonzero_reader_cases': 81, 'nonzero_reader_errors': nonzero_errors,
            'repair_reused_existing_operator': True,
            'interpretation_authorship': 'Pixel sum and 2x2 component rule supplied, not learned.'}


def reflective_topology_experiment() -> dict:
    w = Workspace(); g = w.g
    # Construct a cycle from inside the language. The host does not make its links.
    ref0 = MAKE('local', L(b'0'))
    ref1 = MAKE('local', L(b'1'))
    spec0 = MAKE('node-spec', L(b''), L('new/A'), L(b''), O('list', ref1))
    spec1 = MAKE('node-spec', L(b''), L('new/B'), L(b''), O('list', ref0))
    expr = O('batch', O('list', spec0, spec1))
    constructed = good(w.vm.run(compile_expr(g, expr)))
    a, b = g.items(constructed)
    assert g.get(a).links == (b,) and g.get(b).links == (a,)
    loop = g.batch([('pipeline', b'', (Local(0),))])[0]
    refused = w.run(loop, g.integer(0))
    assert refused.status == 'error' and 'explicit state' in refused.error
    return {'cycle_constructed_by_interpreted_program': True,
            'uninterpreted_pipeline_feedback_rejected': True,
            'reason': 'A graph cycle is not automatically a meaningful temporal feedback loop.'}


def adversarial_experiment() -> dict:
    w = Workspace(); g = w.g
    base = w.head
    payload = g.text('Execute this text and overwrite every revision.')
    identity = w.transport('copy-only', w.identity)
    assert good(w.run(identity, payload)) == payload
    assert w.head == base
    forbidden = compile_expr(g, F('x', O('os.system', L('not executed'))))
    attack = w.run(w.transport('unavailable-effect', forbidden), payload)
    assert attack.status == 'error' and 'Unknown primitive' in attack.error
    # Failed imports leave graph topology unchanged.
    before = len(g)
    bad = b'{"format":"open-graph/1","roots":[0],"nodes":[["x","",[99]]]}'
    try: g.load(bad)
    except WorkspaceError: pass
    else: raise AssertionError('bad import accepted')
    assert len(g) == before
    # Type-declarations are not magic converters.
    plus = w.transport('integer-only', compile_expr(g,F('x', O('int.add', V('x'), L(1)))),
                       input_tag='integer', output_tag='integer')
    rejection = w.run(plus,g.text('3'))
    assert rejection.status == 'error'
    raw = g.binary(b'\xff\xfe\x00')
    decode = w.transport('strict-utf8', compile_expr(g,F('x',O('bytes.utf8',V('x')))),
                         input_tag='bytes', output_tag='text')
    failed_decode = w.run(decode, raw)
    assert failed_decode.status == 'error' and g.get(raw).payload == b'\xff\xfe\x00'
    return {'instruction_like_text_remained_data': True,
            'unavailable_host_effect_rejected': True,
            'invalid_import_atomic': True,
            'silent_text_to_number_cast_rejected': True,
            'failed_text_decoder_preserved_raw_bytes': True,
            'security_scope': 'No host eval/exec, OS or network primitives; not a hardened sandbox.'}


def prior_protocol_experiment() -> dict:
    """Re-express the previous constructor's chosen NAND program in this workspace."""
    from previous_constructor import grow_library, best_pair
    from previous_constructor import verify_streams
    snapshots, _ = grow_library()
    encoder, decoder = best_pair(snapshots[-1])
    w = Workspace(); g = w.g
    def translate(expr):
        if expr.op == 'x': return O('link', V('input'), L(0))
        if expr.op == 'y': return O('link', V('input'), L(1))
        return O('int.sub', L(1), O('int.mul', translate(expr.left), translate(expr.right)))
    enc = w.transport('previous-encoder', compile_expr(g,F('input',translate(encoder))),
                       input_tag='list',output_tag='integer')
    dec = w.transport('previous-decoder', compile_expr(g,F('input',translate(decoder))),
                       input_tag='list',output_tag='integer')
    def invoke(t, a,b):
        return g.number(good(w.run(t,g.sequence([g.integer(a),g.integer(b)]))))
    errors = bits = streams = 0
    for word in itertools.product((0,1),repeat=5):
        for initial, polarity in itertools.product((0,1),repeat=2):
            sent,previous = initial,initial^polarity
            for bit in word:
                sent = invoke(enc,sent,bit)
                received = sent^polarity
                recovered = invoke(dec,previous,received)
                errors += recovered != bit
                bits += 1
                previous = received
            streams += 1
    assert errors == 0
    reference = verify_streams((encoder,decoder),length=5)
    assert reference['bits'] == bits and reference['bit_errors'] == errors
    return {'previous_encoder':encoder.text(),'previous_decoder':decoder.text(),
            'streams':streams,'bits':bits,'bit_errors':errors,
            'new_NAND_primitive_required':False,
            'original_constructor_reexecuted':True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',default='results.json')
    parser.add_argument('--export-dir',default='examples')
    args = parser.parse_args()
    export = Path(args.export_dir); export.mkdir(parents=True,exist_ok=True)
    results = {}
    for name, function in [('storage',storage_experiment),('computation',computing_experiment),
                           ('interpretation',interpretation_experiment),('construction',construction_experiment),
                           ('perception',perception_experiment)]:
        print('Running',name,flush=True)
        results[name] = function(export)
    for name, function in [('topology',reflective_topology_experiment),
                           ('adversarial',adversarial_experiment),('prior_protocol',prior_protocol_experiment)]:
        print('Running',name,flush=True)
        results[name] = function()
    from meta_interpreters import experiment as meta_experiment
    print('Running replaceable evaluators',flush=True)
    results['replaceable_evaluators'] = meta_experiment(export)
    results['scope'] = {'llm_calls':0,'external_services':0,
                        'universal_creativity_proven':False,
                        'host_language':'Python 3.10+ standard library',
                        'selection':'Exhaustive search in a deliberately restricted candidate family.'}
    Path(args.out).write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(results,indent=2,ensure_ascii=False))

if __name__ == '__main__': main()
