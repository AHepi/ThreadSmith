# Primary sources and conceptual precedents

The experiments in this bundle are original execution results. The following
sources establish relevant existing computing ideas; they are not evidence that
this prototype learned the supplied example interpretations or solved creativity.

1. John McCarthy (1960), *Recursive Functions of Symbolic Expressions and Their
   Computation by Machine, Part I*. Author-hosted HTML, particularly the introduction
   and recursive S-functions / universal apply sections:
   https://www-formal.stanford.edu/jmc/recursive/node1.html
   https://www-formal.stanford.edu/jmc/recursive/node3.html

2. *Structure and Interpretation of Computer Programs*, section 4.1,
   *The Metacircular Evaluator*, Scheme/JavaScript comparison edition:
   https://sicp.sourceacademy.org/chapters/4.1.html

3. Same work, section 4.1.5, *Data as Programs*, covering universal evaluators,
   explicit evaluation and the limits of deciding termination:
   https://sicp.sourceacademy.org/chapters/4.1.5.html

4. Same work, section 4.2.1, *Normal Order and Applicative Order*, on strict
   versus delayed argument evaluation:
   https://sicp.sourceacademy.org/chapters/4.2.1.html

5. W3C (2013), *PROV-DM: The PROV Data Model*, particularly entities, activities,
   derivations, revisions and bundles:
   https://www.w3.org/TR/prov-dm/
   The prototype's execution records use a related separation of source,
   transformation and result. It does not claim PROV conformance.

Accessed during the construction of this prototype on 28 September 2026
(Australia/Brisbane).
