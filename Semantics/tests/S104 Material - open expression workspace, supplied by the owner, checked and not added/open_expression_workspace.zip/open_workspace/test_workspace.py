"""Regression and adversarial tests. Run: python -m unittest -v."""
import json
import unittest

from workspace import Graph, Local, Machine, Workspace, WorkspaceError, Limit
from workspace import V,F,C,Q,L,O,I,E,compile_expr
from experiments import constructor_expression, MAKE


class GraphTests(unittest.TestCase):
    def test_different_instances_same_label(self):
        g=Graph(); a,b=g.text('x'),g.text('x')
        self.assertNotEqual(a,b)
        self.assertEqual(g.get(a),g.get(b))

    def test_alias_and_cycle_roundtrip(self):
        g=Graph(); refs=g.batch([('a',b'',(Local(1),Local(1))),('b',b'',(Local(0),))])
        wire=g.dump(refs); clone=Graph(); copy=clone.load(wire)
        self.assertEqual(clone.dump(copy),wire)
        self.assertEqual(clone.get(copy[0]).links,(copy[1],copy[1]))

    def test_invalid_batch_is_atomic(self):
        g=Graph(); a=g.text('keep'); n=len(g)
        with self.assertRaises(WorkspaceError): g.batch([('a',b'',(Local(99),))])
        self.assertEqual(len(g),n)
        self.assertEqual(g.string(a),'keep')

    def test_invalid_wire_is_atomic(self):
        g=Graph()
        with self.assertRaises(WorkspaceError):
            g.load(b'{"format":"open-graph/1","roots":[0],"nodes":[["a","",[1]]]}')
        self.assertEqual(len(g),0)

    def test_unknown_schemas_and_non_utf8(self):
        g=Graph();r=g.add('not-in-registry',bytes(range(256)))
        clone=Graph();p=clone.load(g.dump([r]))[0]
        self.assertEqual(clone.get(p),g.get(r))

    def test_deep_graph_serialization_is_iterative(self):
        g=Graph();r=g.text('leaf')
        for _ in range(5000):r=g.add('nest',links=(r,))
        clone=Graph();wire=g.dump([r]);self.assertEqual(clone.dump(clone.load(wire)),wire)

    def test_boolean_not_integer(self):
        g=Graph()
        with self.assertRaises(WorkspaceError):g.integer(True)
        with self.assertRaises(WorkspaceError):g.number(g.boolean(True))

    def test_allocation_limit(self):
        g=Graph(max_nodes=1);g.text('one')
        with self.assertRaises(Limit):g.text('two')


class MachineTests(unittest.TestCase):
    def setUp(self):self.w=Workspace();self.g=self.w.g
    def evaluate(self,x,**kwargs):return self.w.vm.run(compile_expr(self.g,x),**kwargs)

    def test_identity(self):
        r=self.evaluate(C(F('x',V('x')),L(42)))
        self.assertEqual(self.g.number(r.value),42)

    def test_lexical_scope(self):
        r=self.evaluate(C(C(F('x',F('y',V('x'))),L(40)),L(2)))
        self.assertEqual(self.g.number(r.value),40)

    def test_shadowing(self):
        r=self.evaluate(C(C(F('x',F('x',V('x'))),L(40)),L(2)))
        self.assertEqual(self.g.number(r.value),2)

    def test_unselected_branch_is_not_executed(self):
        r=self.evaluate(I(L(True),L(1),O('fail',L('must not execute'))))
        self.assertEqual(self.g.number(r.value),1)

    def test_quote_is_inert(self):
        code=compile_expr(self.g,O('fail',L('not run')))
        r=self.evaluate(Q(code));self.assertEqual(r.value,code)

    def test_explicit_eval(self):
        code=compile_expr(self.g,O('int.add',L(2),L(3)))
        r=self.evaluate(E(Q(code)));self.assertEqual(self.g.number(r.value),5)

    def test_closure_roundtrip(self):
        r=self.evaluate(C(F('k',F('x',O('int.add',V('k'),V('x')))),L(40)))
        clone=Graph();closure=clone.load(self.g.dump([r.value]))[0];vm=Machine(clone)
        result=vm.run(compile_expr(clone,C(Q(closure),L(2))))
        self.assertEqual(clone.number(result.value),42)

    def test_resume_exported_continuation(self):
        expr=C(F('x',O('int.mul',V('x'),L(3))),O('int.add',L(2),L(5)))
        pause=self.evaluate(expr,fuel=5)
        self.assertEqual(pause.status,'suspended')
        clone=Graph();checkpoint=clone.load(self.g.dump([pause.checkpoint]))[0]
        result=Machine(clone).run(checkpoint=checkpoint)
        self.assertEqual(clone.number(result.value),21)

    def test_deep_non_tail_recursion_not_python_stack(self):
        selfcall=C(C(V('self'),V('self')),O('int.sub',V('n'),L(1)))
        f=F('self',F('n',I(O('int.eq',V('n'),L(0)),L(0),O('int.add',L(1),selfcall))))
        r=self.evaluate(C(C(f,f),L(2000)),fuel=100000)
        self.assertEqual(r.status,'ok')
        self.assertEqual(self.g.number(r.value),2000)

    def test_divergence_suspends(self):
        f=F('x',C(V('x'),V('x')))
        r=self.evaluate(C(f,f),fuel=127)
        self.assertEqual(r.status,'suspended');self.assertEqual(r.steps,127)

    def test_cyclic_program_suspends(self):
        cyclic=self.g.batch([('eval',b'',(Local(0),))])[0]
        r=self.w.vm.run(cyclic,fuel=50)
        self.assertEqual(r.status,'suspended')

    def test_unknown_syntax_is_preserved(self):
        ref=self.g.add('new-language',b'...');r=self.w.vm.run(ref)
        self.assertEqual(r.status,'error');self.assertEqual(self.g.get(ref).payload,b'...')

    def test_no_host_effect(self):
        r=self.evaluate(O('os.system',L('never executed')))
        self.assertEqual(r.status,'error');self.assertIn('Unknown primitive',r.error)

    def test_generated_graph_cycle(self):
        local=MAKE('local',L(b'0'))
        spec=MAKE('node-spec',L(b''),L('self'),L(b''),O('list',local))
        r=self.evaluate(O('batch',O('list',spec)))
        a=self.g.items(r.value)[0];self.assertEqual(self.g.get(a).links,(a,))

    def test_build_arbitrary_bytes(self):
        r=self.evaluate(O('bytes.pack',O('list',L(0),L(255),L(254))))
        self.assertEqual(self.g.get(r.value).payload,b'\x00\xff\xfe')

    def test_bad_byte_is_explicit_error(self):
        r=self.evaluate(O('bytes.pack',O('list',L(256))))
        self.assertEqual(r.status,'error')

    def test_non_callable_is_error(self):
        self.assertEqual(self.evaluate(C(L(5),L(3))).status,'error')


class TransportTests(unittest.TestCase):
    def setUp(self):self.w=Workspace();self.g=self.w.g

    def test_nonidentity_reader_operator_writer(self):
        make=lambda n:compile_expr(self.g,F('x',O('int.add',V('x'),L(n))))
        t=self.w.transport('three-stages',make(2),reader=make(1),writer=make(3))
        r=self.w.run(t,self.g.integer(4))
        self.assertEqual(self.g.number(r.output),10)
        self.assertEqual(self.g.get(r.event).tag,'run')

    def test_input_contract(self):
        t=self.w.transport('number',self.w.identity,input_tag='integer')
        self.assertEqual(self.w.run(t,self.g.text('3')).status,'error')

    def test_output_contract(self):
        t=self.w.transport('number',compile_expr(self.g,F('x',L('not number'))),output_tag='integer')
        self.assertEqual(self.w.run(t,self.g.integer(3)).status,'error')

    def test_pipeline_cycle_not_silent_feedback(self):
        cycle=self.g.batch([('pipeline',b'',(Local(0),))])[0]
        r=self.w.run(cycle,self.g.integer(0))
        self.assertEqual(r.status,'error');self.assertIn('explicit state',r.error)

    def test_generated_transport_survives_registry_removal(self):
        constructor=self.w.transport('generator',compile_expr(self.g,constructor_expression(self.w.identity)))
        spec=self.g.sequence([self.g.text('int.mul'),self.g.integer(3)])
        r=self.w.run(constructor,spec);clone=Graph();t=clone.load(self.g.dump([r.output]))[0]
        w2=Workspace(clone);result=w2.run(t,clone.integer(7))
        self.assertEqual(clone.number(result.output),21)

    def test_source_not_overwritten(self):
        source=self.g.binary(b'\xff');before=self.g.dump([source])
        t=self.w.transport('failing-decoder',compile_expr(self.g,F('x',O('bytes.utf8',V('x')))))
        self.assertEqual(self.w.run(t,source).status,'error')
        self.assertEqual(self.g.dump([source]),before)

    def test_branch_retention_and_stale_selection(self):
        root=self.w.head;a=self.w.revision(root,{'x':self.g.integer(1)})
        b=self.w.revision(root,{'x':self.g.integer(2)})
        self.w.select(a,expected_head=root)
        with self.assertRaises(WorkspaceError):self.w.select(b,expected_head=root)
        self.assertEqual(self.g.number(self.w.lookup('x')),1)
        self.assertEqual(self.g.number(self.w.lookup('x',b)),2)

    def test_cyclic_revision_does_not_hang(self):
        cycle=self.g.batch([('revision',b'',(Local(0),))])[0]
        with self.assertRaises(WorkspaceError):self.w.lookup('missing',cycle)

class InterpreterTests(unittest.TestCase):
    def test_two_general_evaluators(self):
        from meta_interpreters import experiment
        result=experiment()
        self.assertEqual(result['lazy_on_same_expression'],42)
        self.assertEqual(result['church_3_plus_2_under_both_interpreters'],{'strict':5,'lazy':5})

    def test_unused_unknown_can_remain_unknown(self):
        from meta_interpreters import evaluator_source,Subject
        w=Workspace();g=w.g;s=Subject(g)
        t=w.transport('non-strict',compile_expr(g,evaluator_source(True)))
        source=s.call(s.fn(s.literal(7)),g.add('uninterpreted-hole'))
        r=w.run(t,source)
        self.assertEqual(g.number(r.output),7)

if __name__=='__main__':unittest.main()
