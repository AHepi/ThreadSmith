# Open-expression workspace: runnable research prototype

This prototype tests a specific design requirement: the workspace must not be
restricted to a predefined catalogue of meaningful objects or finished programs.
Transports, their interfaces, their connections and alternative interpreters must
be representable and constructible in the same material they operate on.

**Result:** an append-only graph workspace, an iterative lambda evaluator,
replaceable graph-written interpreters, executable reader/operator/writer
transports, graph-written transport constructors, explicit revisions, provenance
records, and exportable suspended computations. The experiments and regression
tests actually run; no language-model API or external service is used.

This is not a claim to have solved universal creativity, learned perception, or
the grounding of arbitrary symbols. The test programs and task criteria are
explicitly supplied by the experimenter. The small search constructs candidates
inside that supplied setting.

## Run

Python 3.10 or later; standard library only. No installation step is required.
Run these commands from the extracted `open_workspace` directory:

```sh
python -m unittest -v
python experiments.py --out results.json --export-dir examples
python run_artifact.py examples/generated_transport.json 10
python run_artifact.py examples/replaceable_evaluator.json --use-stored-input
python run_artifact.py examples/suspended_computation.json --resume
```

The first command currently runs 35 tests. The generated transport returns 33
for input 10. The exported non-strict evaluator returns 42 on its bundled
expression. The last command resumes and completes a computation of 100!.

`results.json` and the two log files contain the recorded run supplied with this
bundle. Re-running regenerates the experiment results and exported example
artifacts. Some logs include elapsed test time, which varies by machine.

## The workspace substrate

Every node has a UTF-8 tag, an exact byte payload, and an ordered tuple of links
to other nodes. Domain-specific tags are not registered with the graph store.
Node references identify occurrences; equal labels or equal payloads do not
silently merge identity. `Graph.batch` supports atomic construction of graphs
with sharing, cycles and forward references. It is also exposed to interpreted
programs through a `batch` graph-construction primitive.

Through the API, old nodes are not rewritten. A change is another node or another
revision. This is an engineering policy, not a metaphysical claim that a creative
agent or its representations must be static.

Export uses a table of reachable nodes and local reference indices. It preserves
sharing, cycles, bytes, and distinct equal-looking occurrences. It is not a
pretty-printer that silently unfolds a graph into a tree. Root references, not
original numeric node IDs, identify objects after import.

The workspace can store uninterpreted material and unfinished expressions.
Storage is separate from execution. A node tag does not automatically acquire
execution authority because it is present in the graph.

## How a transport connects

A transport descriptor is itself a graph node with these five links:

```
transport(input-shape, reader, operator, writer, output-shape)
```

Its reader, operator and writer are expressions that evaluate to functions.
The executor applies them in that order, sharing the step budget. All intermediate
results are graph references. The input and output shape declarations perform
coarse structural checks only. More specific assumptions belong in a reader or
another explicitly executed validator.

A `pipeline` node contains links to transport descriptors. Interpreted programs
can construct those nodes as well as the transport programs. Merely producing a
descriptor does not run it or select it as the active workspace revision.

Execution records link the exact program, input, output and, when available,
a suspended continuation or error. These are derivation records, not guarantees
that the output is correct. Alternative revisions can retain different
interpretations of the same source. Selection checks the expected current head;
a stale request does not silently overwrite another selection.

## Executable core and the universality claim

The core represents variables using de Bruijn indices, functions, application,
quotation, conditionals, graph operations and explicit evaluation. The evaluator
is iterative: it does not use the Python call stack for interpreted recursion.
Captured environments are graph data. On suspension, pending continuation frames
also become graph data and can be exported and resumed in another runtime.

The unrestricted language contains an untyped lambda calculus together with
symbolic constructors and recursion. This is the standard computational route
to universality with unbounded resources. The actual implementation has finite
node, payload, integer, stage and evaluation budgets. No finite collection of
passing examples constitutes a proof of universal interpretive understanding,
and this implementation has not been formally verified against a lambda-calculus
specification.

The workspace separates three requirements:

* **Representation:** arbitrary finite encoded structures can be retained.
* **Computation:** suitable encoded processes can operate on those structures.
* **Interpretation:** different supplied or constructed processes can give the
  same material different operational uses.

None implies that the system automatically discovers a suitable interpretation.
The fixed byte/link substrate is not a claim that all possible experiences are
completely digitised or that every meaningful expression must terminate.

## Executed experiments

### 1. Heterogeneous expression and topology

The mixed example preserves arbitrary bytes, Unicode text, new node kinds,
unfinished material, repeated references and a two-node cycle. Two hundred
seeded random finite graphs also survive export/import exactly in the wire
representation. Equal labels do not merge distinct occurrences.

A shared graph contains 21 nodes. Naively expanding every repeated child into a
fresh tree would require 2,097,151 occurrences; that expanded tree was calculated,
not allocated. The interpreted language also constructs a cyclic graph itself.

### 2. Computation and portable state

Tests include factorials, Church-numeral addition, lexical binding and a captured
function that still returns 42 after export/import. A 100! computation is suspended
after 37 transitions, exported, imported and completed after 2,487 more. A
self-application loop suspends at 1,000 transitions. An allocation-budget test
returns a limit condition instead of silently continuing.

### 3. A notation introduced after the workspace exists

`late/join(late/number(7), late/number(5))` can be stored before any interpretation
is available. Direct native evaluation reports unknown syntax. Two graph-written
interpreters subsequently return 12 and 35. Both interpretations and the original
expression remain available. There are 200 comparisons on independently generated
nested expressions against reference results.

The two interpreters are author-supplied, not learned by the agent.

### 4. A transport constructs other transports and their connections

An interpreted constructor generates 12 arithmetic transport programs, using add
or multiply and constants -2 through 3. A second interpreted constructor generates
all 144 ordered two-stage connections. The selector is given three examples of
`3*x+3`. No single candidate matches more than one example; two connections match
all three. The selected connection is `add 1 -> multiply 3`.

Only the resulting connected graph is exported: 17 nodes, 452 bytes. After import
into a fresh runtime without the constructor or candidate registry, it returns
the target on 198 additional integer inputs with zero errors. This is a bounded
search inside a supplied family, not autonomous invention of the arithmetic
primitives or the task.

### 5. An interpretation discards a later-needed distinction

All 16 binary 2x2 images are enumerated. An initial view retains only the number
of lit pixels. Another task asks for four-neighbour connected-component counts.
Adjacent and diagonal pairs both have two lit pixels but different component
counts. Any predictor given only that summary can get at most 14 of the 16 cases
right under the uniform test distribution. The supplied full-input interpretation
gets all 16 right.

A deliberately violated assumption reveals a second failure: a grayscale input
`[2,0,0,0]` passes the coarse byte-input contract but produces 2 under the binary
rule instead of 1 under a nonzero-foreground convention. An explicit strict reader
rejects it. A different explicit reader maps nonzero samples to foreground and
reuses the same operator: all 81 images with values in {0,1,2} then pass under that
new convention. The original bytes are retained.

Both image rules and both repairs are author-supplied. No image segmentation
algorithm was learned in this test.

### 6. Replace the evaluator, not just a data conversion

`meta_interpreters.py` defines two general lambda interpreters *inside the workspace
language*, using a separate subject-language grammar. They do not invoke the
native `eval` operation to interpret subject expressions.

One evaluates an argument before entering the function. The other delays the
argument until it is needed. On a function that ignores a divergent argument and
returns 42, the strict interpreter exhausts 5,000 transitions; the non-strict one
returns 42. On an ignored unrecognised hole, the strict interpreter reports an
error while the non-strict interpreter again returns 42. The hole remains
uninterpreted, rather than being guessed or repaired.

Both interpreters compute Church 3+2 as five nested successor nodes. The non-strict
interpreter and a subject expression are exported together and work after import
into a fresh workspace. These interpreter implementations were written by the
experimenter; the experiment demonstrates their availability as editable,
portable workspace material, not their autonomous discovery.

### 7. Compatibility with the previous signalling experiment

The previous NAND constructor is rerun. Its selected encoder and decoder are
translated into the new workspace without adding a NAND primitive. All 128
five-bit transmissions across both starting levels and fixed channel polarities
pass: 640 bits, zero errors.

### 8. Operational boundaries

Instruction-like text remains data. An unavailable host-operation name is rejected.
Malformed imported references fail atomically. Text is not silently cast to an
integer. A failed UTF-8 decoder leaves its input bytes intact. A cyclic pipeline
is rejected rather than being assumed to denote a meaningful temporal delay.
The VM can express explicit recursive state transitions, but the host pipeline
scheduler does not yet provide an asynchronous sensor/actuator feedback model.

## What remains deliberately unsolved in this build

There is no learned proposal mechanism, autonomous development of object
boundaries, physical sensor or actuator, language-model connection, automatic
universal translator, garbage collector, or general relevance/attention policy.
The search is deliberately small and supplied; the substrate is substantially
more expressive than that search policy exploits.

Raw and interpreted materials are both retained in these experiments. Finite
memory means a real agent would need explicit retention, forgetting, compression
and reacquisition decisions; no finite lossy summary can preserve every distinction
that every later task might ask for.

Structural contracts are not semantic guarantees. Historical records are not
proofs of truth. A shape-valid graph can still describe an inappropriate or
nonterminating process. Evaluating an expression is an explicit action, not a
property automatically conferred by its storage.

## Safety and engineering limits

This is a trusted local research prototype, not a hardened sandbox for arbitrary
hostile input. There is no Python `eval`, Python `exec`, shell, filesystem or
network operation available to interpreted programs. Import and execution are
separate. Budgets are cooperative semantic limits, not a proof of bounded wall
clock time for every host operation.

The graph's Python implementation and scheduler are trusted. The public host
object is not a capability-security boundary. Exhausting the global graph limit
can prevent recording a final error event; use ample graph headroom and the
per-evaluation budget. Revisions are single-process research bookkeeping, not a
transactional distributed database. The authoring DSL compiler uses Python
recursion for source construction, although graph import/export and execution
are iterative. Arbitrary feedback requires an explicit interpretation of time
and state; merely drawing a cycle is insufficient.

## Files

`workspace.py` contains the substrate and native evaluator. `experiments.py`
contains the main experiments, supplied fixtures and bounded selection.
`meta_interpreters.py` contains the replaceable general evaluators.
`test_workspace.py` contains 35 regression tests. `previous_constructor.py` is
the earlier signalling experiment. `run_artifact.py` demonstrates independent
execution of the exported constructions. `examples/` contains actual graph
artifacts, not screenshots or pseudocode. `SOURCES.md` records conceptual
precedents; the result numbers come from this bundle's executed tests.
